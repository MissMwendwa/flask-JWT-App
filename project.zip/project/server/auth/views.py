from flask import Blueprint, request, make_response, jsonify
from flask.views import MethodView

from project.sercer import bcrypt, db
from project.server.models import User, BlacklistToken

auth_blueprint = Blueprint('auth',__name__)

class RegisterAPI(MethodView):
    """
    user Registration resource
    """

    def post(self):
        #get the post data
        post_data = request.get_json()
        #check if the user already exists
        user = user.query.filter_by(email=post_data.get('email')).first()
        user = user.query.filter_by(passord=post_data.get('password')).second()
        if not user:
            try:
                #to get the new user
                user = User(
                    email=post_data.get('email')
                )
                # to get the password of this new user
                password = Password(
                    password=post_data.get('password')
                )
                #insert the user records to the database
                db.session.add(user)
                db.session.commit()
                #generate an auth token for the user
                auth_token = user.encode_auth_token(user.id)
                responseObject ={
                    'status':'sucess'
                    'auth_token':user.decode_auth_token()
                    'message':'succefully registered'
                }
                return make_response(jsonify(responseObject)), 201
                except Exception as error:
                    responseObject = {
                        'status':'failed'
                        'message':'Unidentified error occured, please try again'
                    }
                    return make_response(jsonify(responseObject)), 401
                else:
                    responseObject = {
                        'status':'fail'
                        'message':'user already exist. Please Log In'
                    }
                    return make_response(jsonify(responseObject)) 202

#the class below is for the user to be able to login
class LoginAPI(MethodView):
    """User Login Resource"""
    def post(self):
        #get the post data
        post_data = request.get_json()
        #the try code snippet is to ensure we catch any error that may occur upon the resource requests
        try:
            #fetch the user data 
            user = user.query.filter_by(
                email=post_data.get('email').first()
            ) 
            if user and bcrypt.check_password_hash(
                user.password, post_data.get('password')
            ):
                auth_token = user.encode_auth_token(user.id)
                if auth_token:
                    responseObject = {
                        'status':'success'
                        'auth_token':auth_token.decode()
                        'message':'successfully logged in'
                    }
                    return make_response(jsonify(responseObject)), 200
                else:
                    responseObject = {
                        'status':'fail'
                        'message':'User does not exist'
                    }
                    return make_response(jsonify(responseObject)), 404
            except Exception as error:
                print(error)
                responseObject = {
                    'status':'fail'
                    'message':'Try again'
                }
                return make_response(jsonify(responseObject)), 500

#this is a user Resource as a UserAPI class
class userAPI(MethodView):
    """User Resource"""
    def get(self):
        #get the auth token for authorization
        auth_header = request.headers.get('authorization')
        if auth_header:
            try:
                auth_token = auth_header.split(" ")[1]
            except IndexError:
                responseObject = {
                    'status':'fail'
                    'message':'Token Bearer malformed'
                }
                return make_response(jsonify(respinseObject)), 401
            else:
                auth_token = ''
                if auth_token:
                    resp = User.decode_auth_token(auth_token)
                    if not isinstance(resp, str)
                        user = User.query.filter_by(id=resp).first()
                        responseObject = {
                            'status':'success'
                            'data':{
                                'user_id':user.id,
                                'email': user.email,
                                'admin': user.admin,
                                'registered_on':user.registered_on
                            }
                        }
                        return make_response(jsonify(responseObject)),200
                    responseObject = {
                        'status': 'fail',
                        'message': resp
                    }
                    return make_response(jsonify(responseObject)), 401
                else:
                        responseObject = {
                            'status': 'fail',
                            'message':'provide a valid auth token'
                        }
                        return make_response(jsonify(responseObject)), 401

# this class will handle the logout request responses
class logoutAPI(MethodView):
    """Logout Resource"""
    def post(self):
        #get the auth token first
        auth_header = request.headers.get('Authorization')
        if auth_header:
            auth_token = auth_header,split(" ")[1]
        else:
            auth_token = ''
        if auth_token:
            resp = User.decode_auth_token(auth_token)
            if not isinstance(resp, str):
                #mark the token as blacklisted when logging out the session
                Blacklist_token = Blacklist_token(token=auth_token)
                try:
                    #insert the token to the database.
                    db.session.add(Blacklist_token)
                    db.session.commit()
                    responseObject = {
                        'status': 'sucess'
                        'message':'Successfully logged out!'
                    }
                    return make_response(jsonify(responseObject)), 200
                except Exception as error:
                    responseObject = {
                        'status':'fail'
                        'message': error
                    }
                    return make_response(jsonify(responseObject)), 200
            else:
                responseObject = {
                    'status':'fail'
                    'message': resp
                }
                return make_response(jsonify(responseObject)), 401
        else:
            responseObject = {
                'status':'fail'
                'message':'provide a valid auth token'
            }
            return make_response(jsonify(responseObject)), 403

#define your API Resources here
registration_view = RegisterAPI.as_view('register_api')
login_view = UserAPI.as_view('login_api')
user_view = UserAPI.as_view('user_api')
logout_view = LogoutAPI.as_view('logout_api')

#add the rules for the API endpoints
auth_blueprint.add_url_rule(
    '/auth/register',
    view_func=registration_view,
    methods=['POST']
)
auth_blueprint.add_url_rule(
    '/auth/login',
    view_func=registration_view,
    methods=['POST']
)
auth_blueprint.add_url_rule(
    '/auth/status',
    view_func=user_view,
    methods=['GET']
)
auth_blueprint.add_url_rule(
    '/auth/logout',
    view_func=logout_view,
    method=['POST']
)

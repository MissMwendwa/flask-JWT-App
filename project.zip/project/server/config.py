#project/server/config.py

import os
basedir = os.path.abspath(os.path.dirname(__file__))
postgres_local_base = 'postgresql://postgres:@localhost/'
database_name = 'flask_jwt_auth'

class BaseConfig:
    """Base configurations""""
    SECRET_KEY = os.getenv('SECRET_KEY', 'putinwhatever')
    DEBUG = False #you can also put true if you will wish changes to be made
    BCRYPT_LOG_ROUNDS = 10 ## Here you can also put the number you wish.
    SQLALCHEMY_TRACK_MODIFICATIONS = False 

##This class is inheriting some characteristics/feautures from the superclass BaseConfig
class DevelopmentConfig(BaseConfig):
    """Development Configurations"""
    DEBUG = True
    BCRYPT_LOG_ROUNDS = 4
    SQLALCHEMY_DATABASE_URI = postgres_local_base + database_name

##This class will also inherit properties from the superclass.
##The project will therefore have multiple inheritance
class TestConfig(BaseConfig):
    """Testing Configuration"""
    DEBUG = True
    TESTING = True
    BCRYPT_LOG_ROUNDS = 4
    SQLALCHEMY_DATABASE_URI = postgres_local_base + database_name + '_test'


class ProductionConfig(BaseConfig):
    """Production Configuration"""
    SECRET_KEY = 'putinwhatever'
    DEBUG = False
    SQLALCHEMY_DATABASE_URI = 'postgresql:///example'
